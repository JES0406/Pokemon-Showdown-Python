class ReturnBackException(Exception):
    pass

class NoPPException(Exception):
    pass