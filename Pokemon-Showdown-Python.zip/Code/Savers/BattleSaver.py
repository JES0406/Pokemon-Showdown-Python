from Code.Savers.BaseSaver import BaseSaver

class BattleSaver(BaseSaver):
    '''
    This class is only for the name, the rest of the code is in the BaseSaver class
    '''
    def __init__(self):
        super().__init__()